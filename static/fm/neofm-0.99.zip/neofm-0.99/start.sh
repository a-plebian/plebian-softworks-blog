#!/bin/bash
java --illegal-access=permit -jar lib/neofm-0.99-all.jar
